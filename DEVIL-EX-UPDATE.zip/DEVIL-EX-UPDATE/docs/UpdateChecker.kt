package com.devilex.updater

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Parsed response of api/check_update.php */
data class UpdateInfo(
    val updateAvailable: Boolean,
    val mandatory: Boolean,
    val latestVersion: String,
    val latestVersionCode: Int,
    val title: String,
    val message: String,
    val description: String,
    val changelog: String,
    val downloadUrl: String,
    val updateButton: String,
    val cancelButton: String,
    val darkTheme: Boolean,
    val maintenanceMode: Boolean,
    val maintenanceMessage: String
)

object DevilExUpdater {
    // 1) Set these two values. APP_ID is shown in the admin panel (Manage Applications -> Edit).
    private const val BASE_URL = "https://your-domain.com/devil-ex-update"
    private const val APP_ID = "PASTE_YOUR_32_CHARACTER_APP_ID"

    /** Call from onCreate/onResume of your main activity. */
    fun check(activity: AppCompatActivity) {
        val versionCode = currentVersionCode(activity)
        activity.lifecycleScope.launch {
            val info = withContext(Dispatchers.IO) { fetch(versionCode) } ?: return@launch // network error: never block the user
            if (activity.isFinishing || activity.isDestroyed) return@launch
            when {
                info.maintenanceMode -> showMaintenance(activity, info)
                info.updateAvailable -> showUpdate(activity, info, versionCode)
            }
        }
    }

    private fun currentVersionCode(a: Activity): Int {
        val pi = a.packageManager.getPackageInfo(a.packageName, 0)
        return PackageInfoCompat.getLongVersionCode(pi).toInt()
    }

    private fun fetch(versionCode: Int): UpdateInfo? = try {
        val url = "$BASE_URL/api/check_update.php?app_id=${URLEncoder.encode(APP_ID, "UTF-8")}&version_code=$versionCode"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000; c.requestMethod = "GET"
        val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }
        c.disconnect()
        val j = JSONObject(body ?: "")
        if (!j.optBoolean("success", false)) null else UpdateInfo(
            updateAvailable = j.optBoolean("update_available"),
            mandatory = j.optBoolean("mandatory"),
            latestVersion = j.optString("latest_version"),
            latestVersionCode = j.optInt("latest_version_code"),
            title = j.optString("title"),
            message = j.optString("message"),
            description = j.optString("description"),
            changelog = j.optString("changelog"),
            downloadUrl = j.optString("download_url"),
            updateButton = j.optString("update_button", "Update Now"),
            cancelButton = j.optString("cancel_button", "Later"),
            darkTheme = j.optString("theme") == "dark",
            maintenanceMode = j.optBoolean("maintenance_mode"),
            maintenanceMessage = j.optString("maintenance_message")
        )
    } catch (e: Exception) { null }

    private fun builder(a: Activity, dark: Boolean) = AlertDialog.Builder(
        a, if (dark) android.R.style.Theme_DeviceDefault_Dialog_Alert else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
    )

    // Maintenance: cannot be dismissed, the only action is to close the app.
    private fun showMaintenance(a: Activity, i: UpdateInfo) {
        builder(a, i.darkTheme)
            .setTitle("Under Maintenance")
            .setMessage(i.maintenanceMessage)
            .setCancelable(false)
            .setPositiveButton("Exit") { _, _ -> a.finishAffinity() }
            .show().setCanceledOnTouchOutside(false)
    }

    private fun showUpdate(a: Activity, i: UpdateInfo, currentCode: Int) {
        val text = buildString {
            append(i.message)
            if (i.description.isNotBlank()) append("\n\n").append(i.description)
            if (i.changelog.isNotBlank()) append("\n\nWhat's new:\n").append(i.changelog)
        }
        val b = builder(a, i.darkTheme).setTitle(i.title).setMessage(text)

        if (i.mandatory) {
            // MANDATORY: no cancel button, back button and outside tap disabled.
            b.setCancelable(false).setPositiveButton(i.updateButton, null)
            val d = b.create()
            d.setCanceledOnTouchOutside(false)
            d.show()
            // Override the click so the dialog stays open after tapping Update.
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { startDownload(a, i, currentCode) }
        } else {
            // OPTIONAL: Update Now + Later.
            b.setCancelable(true)
                .setPositiveButton(i.updateButton) { _, _ -> startDownload(a, i, currentCode) }
                .setNegativeButton(i.cancelButton) { d, _ -> d.dismiss() }
                .show()
        }
    }

    private fun startDownload(a: Activity, i: UpdateInfo, currentCode: Int) {
        report("report_download", "version_code=$currentCode&target_version_code=${i.latestVersionCode}")
        try {
            a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(i.downloadUrl)))
        } catch (e: ActivityNotFoundException) { /* no browser installed */ }
    }

    /** Optional analytics, fire-and-forget. Call report("report_update", "from_version_code=100&to_version_code=200") after an update. */
    fun report(endpoint: String, params: String) {
        Thread {
            try {
                val c = URL("$BASE_URL/api/$endpoint.php").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 6000; c.readTimeout = 6000
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write("app_id=$APP_ID&$params".toByteArray()) }
                c.responseCode; c.disconnect()
            } catch (e: Exception) { }
        }.start()
    }
}

/* Usage in MainActivity:
 *
 *   override fun onCreate(savedInstanceState: Bundle?) {
 *       super.onCreate(savedInstanceState)
 *       setContentView(R.layout.activity_main)
 *       DevilExUpdater.check(this)
 *   }
 *
 * AndroidManifest.xml:  <uses-permission android:name="android.permission.INTERNET" />
 * build.gradle:         implementation "androidx.lifecycle:lifecycle-runtime-ktx:2.7.0"
 *                       implementation "androidx.core:core-ktx:1.12.0"
 * If your server URL is http (not https) add android:usesCleartextTraffic="true" - https is strongly recommended.
 */
