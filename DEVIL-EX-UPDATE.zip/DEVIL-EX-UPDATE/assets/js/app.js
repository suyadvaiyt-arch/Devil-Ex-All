(function () {
  'use strict';
  var body = document.body;

  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-sidebar-toggle]')) { body.classList.toggle('nav-open'); }
    if (e.target.closest('[data-pubnav-toggle]')) { body.classList.toggle('pubnav-open'); }

    var c = e.target.closest('[data-copy]');
    if (c) {
      var text = c.getAttribute('data-copy');
      var done = function () {
        var old = c.innerHTML; c.innerHTML = '<i class="fa-solid fa-check"></i> Copied';
        setTimeout(function () { c.innerHTML = old; }, 1400);
      };
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done);
      } else {
        var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (err) {}
        document.body.removeChild(ta);
      }
    }
  });

  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) { e.preventDefault(); } });
  });

  document.querySelectorAll('[data-autohide]').forEach(function (a) {
    setTimeout(function () { a.classList.add('fade-out'); setTimeout(function () { a.remove(); }, 400); }, 6000);
  });

  var sel = document.querySelector('[data-app-switch]');
  if (sel) { sel.addEventListener('change', function () { sel.form.submit(); }); }

  // Live dialog preview on the Update Dialog Manager page.
  var form = document.getElementById('cfg-form');
  var pv = document.getElementById('dialog-preview');
  if (form && pv) {
    var q = function (n) { return form.elements[n]; };
    var set = function (id, v) { var el = document.getElementById(id); if (el) { el.textContent = v; } };
    var render = function () {
      var maint = q('maintenance_mode').checked, mand = q('update_type').value === 'mandatory';
      pv.className = 'dialog-preview ' + (q('theme').value === 'dark' ? 'dark' : 'light');
      set('pv-title', maint ? 'Under Maintenance' : q('title').value);
      set('pv-message', maint ? q('maintenance_message').value : q('message').value);
      set('pv-desc', maint ? '' : q('description').value);
      set('pv-update', maint ? 'Exit' : q('update_button_text').value);
      set('pv-cancel', q('cancel_button_text').value);
      document.getElementById('pv-cancel').style.display = (maint || mand) ? 'none' : '';
      set('pv-state', !q('dialog_enabled').checked && !maint ? 'Dialog is OFF - users will not see it' :
        (maint ? 'Maintenance - cannot be dismissed' : (mand ? 'Mandatory - cannot be dismissed' : 'Optional - user can choose Later')));
    };
    form.addEventListener('input', render); form.addEventListener('change', render); render();
  }
})();
