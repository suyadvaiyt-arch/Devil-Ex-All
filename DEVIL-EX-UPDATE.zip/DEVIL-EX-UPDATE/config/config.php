<?php
/** DEVIL EX Update Control - general configuration. */
define('ROOT_DIR', dirname(__DIR__));

const APP_NAME     = 'DEVIL EX';
const APP_TAGLINE  = 'Online APK Update Control System';
const APP_VERSION  = '1.0.0';

// Optional: force the public base URL (no trailing slash), e.g. 'https://yourname.rf.gd/devil-ex-update'.
// Leave empty to auto-detect.
const BASE_URL = '';

const UPLOAD_DIR_REL       = 'uploads/app-icons/';
const UPLOAD_MAX_BYTES     = 1048576;  // 1 MB icon limit
const SESSION_IDLE_SECONDS = 1800;     // auto logout after 30 min idle
const DEBUG                = false;    // never enable on a public site

error_reporting(E_ALL);
ini_set('display_errors', DEBUG ? '1' : '0');
ini_set('log_errors', '1');
date_default_timezone_set('UTC');
