<?php
/**
 * DEVIL EX Update Control - database connection.
 * Edit these four values using the MySQL details from your InfinityFree control panel
 * (MySQL Databases section). Host looks like sql123.infinityfree.com (NOT localhost).
 */
define('DB_HOST', 'sqlXXX.infinityfree.com');
define('DB_NAME', 'if0_XXXXXXXX_devilex');
define('DB_USER', 'if0_XXXXXXXX');
define('DB_PASS', 'your-mysql-password');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    }
    return $pdo;
}
