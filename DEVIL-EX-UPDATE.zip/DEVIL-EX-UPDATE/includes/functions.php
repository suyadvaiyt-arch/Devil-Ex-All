<?php
/** Core helpers for DEVIL EX Update Control (shared by web pages and the API). */

const CONFIG_FIELDS = [
    'dialog_enabled', 'update_type', 'latest_version', 'latest_version_code',
    'min_supported_version_code', 'title', 'message', 'description', 'download_url',
    'update_button_text', 'cancel_button_text', 'changelog', 'theme',
    'maintenance_mode', 'maintenance_message',
];

/* ---------- output / http ---------- */
function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
        || (($_SERVER['SERVER_PORT'] ?? '') == 443);
}

function site_url(string $path = ''): string
{
    if (BASE_URL !== '') {
        return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
    }
    $scheme = is_https() ? 'https' : 'http';
    $host   = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    if (substr($dir, -4) === '/api') {
        $dir = substr($dir, 0, -4);
    }
    return $scheme . '://' . $host . $dir . '/' . ltrim($path, '/');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function json_out(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['t' => $type, 'm' => $msg];
}

function render_flashes(): void
{
    if (empty($_SESSION['flash'])) {
        return;
    }
    $icons = ['success' => 'circle-check', 'danger' => 'circle-exclamation', 'info' => 'circle-info'];
    foreach ($_SESSION['flash'] as $f) {
        $i = $icons[$f['t']] ?? 'circle-info';
        echo '<div class="alert alert-' . e($f['t']) . '" data-autohide><i class="fa-solid fa-' . $i . '"></i> <span>' . e($f['m']) . '</span></div>';
    }
    unset($_SESSION['flash']);
}

function fmt_date(?string $dt): string
{
    return $dt ? date('M j, Y g:i A', strtotime($dt)) : '—';
}

function badge(string $text, string $cls = 'gray'): string
{
    return '<span class="badge badge-' . e($cls) . '">' . e($text) . '</span>';
}

/* ---------- settings ---------- */
function get_setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query('SELECT setting_key, setting_value FROM system_settings') as $r) {
                $cache[$r['setting_key']] = (string)$r['setting_value'];
            }
        } catch (Throwable $t) {
            $cache = [];
        }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    db()->prepare('INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
                   ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)')
        ->execute([$key, $value]);
}

function client_ip(): string
{
    static $ip = null;
    if ($ip !== null) {
        return $ip;
    }
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    // Only trust the Cloudflare header when the admin enabled it in Settings.
    if (get_setting('trust_cf_ip', '0') === '1' && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])
        && filter_var($_SERVER['HTTP_CF_CONNECTING_IP'], FILTER_VALIDATE_IP)) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    return $ip;
}

/* ---------- rate limiting ---------- */
function rl_now(): string
{
    return gmdate('Y-m-d H:i:s');
}

/** Counts a hit. Returns false when the limit for the current window is already reached. */
function rate_limit_hit(string $bucket, string $id, int $max, int $win): bool
{
    $pdo = db();
    $id  = substr($id, 0, 64);
    if (mt_rand(1, 100) === 1) {
        $pdo->prepare('DELETE FROM rate_limits WHERE window_start < ?')->execute([gmdate('Y-m-d H:i:s', time() - 86400)]);
    }
    $st = $pdo->prepare('SELECT id, hits, window_start FROM rate_limits WHERE bucket = ? AND identifier = ?');
    $st->execute([$bucket, $id]);
    $r = $st->fetch();
    if (!$r) {
        try {
            $pdo->prepare('INSERT INTO rate_limits (bucket, identifier, hits, window_start) VALUES (?, ?, 1, ?)')
                ->execute([$bucket, $id, rl_now()]);
        } catch (PDOException $e) {
            // concurrent insert: ignore
        }
        return true;
    }
    if (strtotime($r['window_start'] . ' UTC') + $win <= time()) {
        $pdo->prepare('UPDATE rate_limits SET hits = 1, window_start = ? WHERE id = ?')->execute([rl_now(), $r['id']]);
        return true;
    }
    if ((int)$r['hits'] >= $max) {
        return false;
    }
    $pdo->prepare('UPDATE rate_limits SET hits = hits + 1 WHERE id = ?')->execute([$r['id']]);
    return true;
}

/** Seconds left in the block, or 0 when not blocked. Does not count a hit. */
function rate_limit_blocked(string $bucket, string $id, int $max, int $win): int
{
    $st = db()->prepare('SELECT hits, window_start FROM rate_limits WHERE bucket = ? AND identifier = ?');
    $st->execute([$bucket, substr($id, 0, 64)]);
    $r = $st->fetch();
    if (!$r) {
        return 0;
    }
    $end = strtotime($r['window_start'] . ' UTC') + $win;
    return ($end > time() && (int)$r['hits'] >= $max) ? $end - time() : 0;
}

function rate_limit_clear(string $bucket, string $id): void
{
    db()->prepare('DELETE FROM rate_limits WHERE bucket = ? AND identifier = ?')->execute([$bucket, substr($id, 0, 64)]);
}

/* ---------- validation ---------- */
function clean_str($v, int $max): string
{
    $v = trim((string)$v);
    return function_exists('mb_substr') ? mb_substr($v, 0, $max, 'UTF-8') : substr($v, 0, $max);
}

function valid_url(string $u): bool
{
    return strlen($u) <= 500 && filter_var($u, FILTER_VALIDATE_URL) !== false && preg_match('#^https?://#i', $u) === 1;
}

function valid_version(string $v): bool
{
    return strlen($v) <= 30 && preg_match('/^[0-9]+(\.[0-9]+){0,3}([-+][A-Za-z0-9.]+)?$/', $v) === 1;
}

function valid_app_id(string $v): bool
{
    return preg_match('/^[a-f0-9]{32}$/', $v) === 1;
}

/** @return array{0:array,1:array} cleaned values and error list */
function validate_app(array $in): array
{
    $c = [
        'name'                 => clean_str($in['name'] ?? '', 100),
        'package_name'         => clean_str($in['package_name'] ?? '', 150),
        'current_version'      => clean_str($in['current_version'] ?? '', 30),
        'latest_version'       => clean_str($in['latest_version'] ?? '', 30),
        'min_supported_version' => clean_str($in['min_supported_version'] ?? '', 30),
        'download_url'         => clean_str($in['download_url'] ?? '', 500),
        'description'          => clean_str($in['description'] ?? '', 2000),
        'is_active'            => !empty($in['is_active']) ? 1 : 0,
    ];
    $err = [];
    if ($c['name'] === '') {
        $err[] = 'Application name is required.';
    }
    if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/', $c['package_name'])) {
        $err[] = 'Enter a valid Android package name, for example com.devilex.app.';
    }
    foreach (['current_version' => 'Current version', 'latest_version' => 'Latest version', 'min_supported_version' => 'Minimum supported version'] as $k => $l) {
        if (!valid_version($c[$k])) {
            $err[] = $l . ' must look like 1.0.0.';
        }
    }
    if ($c['download_url'] !== '' && !valid_url($c['download_url'])) {
        $err[] = 'APK download URL must be a valid http(s) link.';
    }
    return [$c, $err];
}

/** @return array{0:array,1:array} */
function validate_config(array $in): array
{
    $int = static function ($v): int {
        return (is_numeric($v) && (string)(int)$v === trim((string)$v)) ? (int)$v : -1;
    };
    $c = [
        'dialog_enabled'            => !empty($in['dialog_enabled']) ? 1 : 0,
        'update_type'               => ($in['update_type'] ?? '') === 'mandatory' ? 'mandatory' : 'optional',
        'latest_version'            => clean_str($in['latest_version'] ?? '', 30),
        'latest_version_code'       => $int($in['latest_version_code'] ?? ''),
        'min_supported_version_code' => $int($in['min_supported_version_code'] ?? ''),
        'title'                     => clean_str($in['title'] ?? '', 150),
        'message'                   => clean_str($in['message'] ?? '', 500),
        'description'               => clean_str($in['description'] ?? '', 2000),
        'download_url'              => clean_str($in['download_url'] ?? '', 500),
        'update_button_text'        => clean_str($in['update_button_text'] ?? '', 40),
        'cancel_button_text'        => clean_str($in['cancel_button_text'] ?? '', 40),
        'changelog'                 => clean_str($in['changelog'] ?? '', 5000),
        'theme'                     => ($in['theme'] ?? '') === 'dark' ? 'dark' : 'light',
        'maintenance_mode'          => !empty($in['maintenance_mode']) ? 1 : 0,
        'maintenance_message'       => clean_str($in['maintenance_message'] ?? '', 500),
    ];
    $err = [];
    if (!valid_version($c['latest_version'])) {
        $err[] = 'Latest version must look like 2.0.0.';
    }
    if ($c['latest_version_code'] < 1 || $c['latest_version_code'] > 2147483647) {
        $err[] = 'Latest version code must be a whole number of at least 1.';
    }
    if ($c['min_supported_version_code'] < 0 || $c['min_supported_version_code'] > 2147483647) {
        $err[] = 'Minimum supported version code must be a whole number (0 or more).';
    } elseif ($c['latest_version_code'] >= 1 && $c['min_supported_version_code'] > $c['latest_version_code']) {
        $err[] = 'Minimum supported version code cannot be higher than the latest version code.';
    }
    if ($c['title'] === '') {
        $err[] = 'Update title is required.';
    }
    if ($c['message'] === '') {
        $err[] = 'Update message is required.';
    }
    if ($c['update_button_text'] === '' || $c['cancel_button_text'] === '') {
        $err[] = 'Both button texts are required.';
    }
    if ($c['download_url'] !== '' && !valid_url($c['download_url'])) {
        $err[] = 'APK download URL must be a valid http(s) link.';
    }
    if ($c['dialog_enabled'] && $c['download_url'] === '') {
        $err[] = 'An APK download URL is required while the update dialog is enabled.';
    }
    if ($c['maintenance_mode'] && $c['maintenance_message'] === '') {
        $err[] = 'Maintenance message is required while maintenance mode is on.';
    }
    return [$c, $err];
}

/* ---------- applications & configs ---------- */
function gen_app_id(): string
{
    $st = db()->prepare('SELECT 1 FROM applications WHERE app_id = ?');
    do {
        $id = bin2hex(random_bytes(16));
        $st->execute([$id]);
    } while ($st->fetchColumn());
    return $id;
}

function app_by_pk(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM applications WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function default_config(array $app): array
{
    return [
        'dialog_enabled' => 0, 'update_type' => 'optional',
        'latest_version' => $app['latest_version'] ?? '1.0.0',
        'latest_version_code' => 1, 'min_supported_version_code' => 1,
        'title' => 'New Update Available', 'message' => 'A new version is available.',
        'description' => '', 'download_url' => $app['download_url'] ?? '',
        'update_button_text' => 'Update Now', 'cancel_button_text' => 'Later',
        'changelog' => '', 'theme' => 'light', 'maintenance_mode' => 0,
        'maintenance_message' => 'We are under maintenance. Please try again later.',
    ];
}

function get_config(int $appPk, array $app): array
{
    $st = db()->prepare('SELECT * FROM update_configs WHERE application_id = ?');
    $st->execute([$appPk]);
    $row = $st->fetch();
    if (!$row) {
        return default_config($app);
    }
    $cfg = [];
    foreach (CONFIG_FIELDS as $f) {
        $cfg[$f] = $row[$f] ?? '';
    }
    return $cfg;
}

function save_update_config(int $appPk, array $c, array $admin): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT latest_version FROM update_configs WHERE application_id = ? FOR UPDATE');
        $st->execute([$appPk]);
        $prev = $st->fetch();

        $params = [];
        foreach (CONFIG_FIELDS as $f) {
            $params[$f] = $c[$f];
        }
        $params['uid'] = $admin['id'];
        $params['app'] = $appPk;

        if ($prev) {
            $set = implode(', ', array_map(static fn($f) => "$f = :$f", CONFIG_FIELDS));
            $pdo->prepare("UPDATE update_configs SET $set, updated_by = :uid WHERE application_id = :app")->execute($params);
        } else {
            $cols = implode(', ', CONFIG_FIELDS);
            $ph   = ':' . implode(', :', CONFIG_FIELDS);
            $pdo->prepare("INSERT INTO update_configs (application_id, updated_by, $cols) VALUES (:app, :uid, $ph)")->execute($params);
        }

        $pdo->prepare('UPDATE applications SET latest_version = ? WHERE id = ?')->execute([$c['latest_version'], $appPk]);

        $status = $c['maintenance_mode'] ? 'maintenance' : ($c['dialog_enabled'] ? 'enabled' : 'disabled');
        $pdo->prepare('INSERT INTO update_history
            (application_id, admin_id, admin_name, previous_version, new_version, update_type, status, config_snapshot)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $appPk, $admin['id'], $admin['display_name'],
                $prev['latest_version'] ?? null, $c['latest_version'], $c['update_type'], $status,
                json_encode($c, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]);
        $pdo->commit();
    } catch (Throwable $t) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $t;
    }
}

/* ---------- uploads ---------- */
/** @return array{0:?string,1:?string} relative path (or null) and error (or null) */
function handle_icon_upload(array $f): array
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return [null, null];
    }
    if ($f['error'] !== UPLOAD_ERR_OK) {
        return [null, 'Icon upload failed. Try a smaller image.'];
    }
    if ($f['size'] > UPLOAD_MAX_BYTES) {
        return [null, 'Icon must be 1 MB or smaller.'];
    }
    if (!is_uploaded_file($f['tmp_name'])) {
        return [null, 'Invalid upload.'];
    }
    $info = @getimagesize($f['tmp_name']);
    $map  = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($map[$info[2]])) {
        return [null, 'Icon must be a JPG, PNG or WEBP image.'];
    }
    if ($info[0] > 2048 || $info[1] > 2048) {
        return [null, 'Icon dimensions must not exceed 2048 x 2048.'];
    }
    $name = bin2hex(random_bytes(12)) . '.' . $map[$info[2]];
    $dir  = ROOT_DIR . '/' . UPLOAD_DIR_REL;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) {
        return [null, 'Upload folder is missing and could not be created.'];
    }
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) {
        return [null, 'Could not save the uploaded icon (check folder permissions).'];
    }
    @chmod($dir . $name, 0644);
    return [UPLOAD_DIR_REL . $name, null];
}

function delete_icon(?string $path): void
{
    if ($path && strpos($path, UPLOAD_DIR_REL) === 0) {
        $full = ROOT_DIR . '/' . UPLOAD_DIR_REL . basename($path);
        if (is_file($full)) {
            @unlink($full);
        }
    }
}

function icon_url(?string $path): string
{
    return $path ? site_url($path) : site_url('assets/images/default-icon.svg');
}

function purge_logs(int $days): int
{
    $days = max(0, $days);
    $st = db()->prepare('DELETE FROM api_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ' . $days . ' DAY)');
    $st->execute();
    return $st->rowCount();
}
