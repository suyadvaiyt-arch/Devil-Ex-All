<?php
/** CSRF protection (synchronizer token stored in the session). */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): bool
{
    $t = $_POST['csrf_token'] ?? '';
    return is_string($t) && $t !== '' && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}

function csrf_require(): void
{
    if (!csrf_verify()) {
        http_response_code(419);
        exit('Security token expired. Go back, refresh the page and try again.');
    }
}
