<?php
$items = [
    ['dashboard',   'dashboard.php',       'gauge-high',        'Dashboard'],
    ['apps',        'applications.php',    'mobile-screen',     'Manage Applications'],
    ['add',         'add-application.php', 'plus',              'Add New Application'],
    ['manager',     'update-manager.php',  'sliders',           'Update Dialog Manager'],
    ['history',     'update-history.php',  'clock-rotate-left', 'Update History'],
    ['api',         'api-management.php',  'plug',              'API Management'],
    ['settings',    'settings.php',        'gear',              'System Settings'],
    ['profile',     'profile.php',         'user-shield',       'Admin Profile'],
];
?>
<aside class="sidebar glass" id="sidebar">
  <a class="brand" href="dashboard.php"><img src="assets/images/logo.svg" alt="" width="38" height="38"><span><?= e(get_setting('site_name', APP_NAME)) ?></span></a>
  <nav class="side-nav">
    <?php foreach ($items as [$key, $href, $icon, $label]): ?>
      <a href="<?= e($href) ?>" class="<?= $active === $key ? 'active' : '' ?>"><i class="fa-solid fa-<?= e($icon) ?>"></i><span><?= e($label) ?></span></a>
    <?php endforeach; ?>
  </nav>
  <div class="side-foot">
    <a href="status.php" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>Public site</span></a>
    <form method="post" action="logout.php">
      <?= csrf_field() ?>
      <button type="submit" class="side-logout"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></button>
    </form>
  </div>
</aside>
