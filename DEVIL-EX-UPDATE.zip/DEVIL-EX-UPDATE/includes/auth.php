<?php
/** Admin authentication and session security. */
function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('DXSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    if (isset($_SESSION['last_active']) && time() - $_SESSION['last_active'] > SESSION_IDLE_SECONDS) {
        $_SESSION = [];
        session_regenerate_id(true);
    }
    $_SESSION['last_active'] = time();
}

function session_fp(): string
{
    return hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
}

function is_logged_in(): bool
{
    return !empty($_SESSION['admin_id']) && hash_equals($_SESSION['fp'] ?? '', session_fp());
}

function current_admin(): ?array
{
    static $admin = null;
    if (!is_logged_in()) {
        return null;
    }
    if ($admin === null) {
        $st = db()->prepare('SELECT id, username, email, display_name FROM admins WHERE id = ?');
        $st->execute([(int)$_SESSION['admin_id']]);
        $admin = $st->fetch() ?: null;
        if ($admin === null) {
            admin_logout();
        }
    }
    return $admin;
}

function require_login(): array
{
    $a = current_admin();
    if ($a === null) {
        redirect('login.php');
    }
    return $a;
}

/** @return array{0:bool,1:string} */
function attempt_login(string $username, string $password): array
{
    $ip   = client_ip();
    $max  = max(1, (int)get_setting('login_max_attempts', '5'));
    $win  = max(1, (int)get_setting('login_lockout_minutes', '15')) * 60;
    $ukey = hash('sha256', strtolower($username));

    foreach ([['login', $ip], ['loginu', $ukey]] as [$bucket, $ident]) {
        $wait = rate_limit_blocked($bucket, $ident, $max, $win);
        if ($wait > 0) {
            return [false, 'Too many failed attempts. Try again in ' . (int)ceil($wait / 60) . ' minute(s).'];
        }
    }

    $st = db()->prepare('SELECT * FROM admins WHERE username = ? OR email = ? LIMIT 1');
    $st->execute([$username, $username]);
    $admin = $st->fetch();

    if ($admin) {
        $ok = password_verify($password, $admin['password_hash']);
    } else {
        password_hash($password, PASSWORD_DEFAULT); // equalise timing
        $ok = false;
    }

    if (!$ok) {
        rate_limit_hit('login', $ip, 1000000, $win);
        rate_limit_hit('loginu', $ukey, 1000000, $win);
        return [false, 'Invalid username or password.'];
    }

    rate_limit_clear('login', $ip);
    rate_limit_clear('loginu', $ukey);
    session_regenerate_id(true);
    $_SESSION['admin_id'] = (int)$admin['id'];
    $_SESSION['fp']       = session_fp();

    if (password_needs_rehash($admin['password_hash'], PASSWORD_DEFAULT)) {
        db()->prepare('UPDATE admins SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $admin['id']]);
    }
    db()->prepare('UPDATE admins SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?')
        ->execute([$ip, $admin['id']]);
    return [true, ''];
}

function admin_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}
