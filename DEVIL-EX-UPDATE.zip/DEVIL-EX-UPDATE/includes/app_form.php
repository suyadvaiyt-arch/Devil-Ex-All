<?php
/** Shared application form. Expects $app (array), $isEdit (bool). */
?>
<form method="post" enctype="multipart/form-data" autocomplete="off">
  <?= csrf_field() ?>
  <div class="grid-2">
    <div class="field"><label for="name">Application name</label><input type="text" id="name" name="name" required maxlength="100" value="<?= e($app['name']) ?>"></div>
    <div class="field"><label for="package_name">Package name</label><input type="text" id="package_name" name="package_name" required maxlength="150" placeholder="com.devilex.app" value="<?= e($app['package_name']) ?>"></div>
  </div>
  <div class="grid-3">
    <div class="field"><label for="current_version">Current version</label><input type="text" id="current_version" name="current_version" required value="<?= e($app['current_version']) ?>"></div>
    <div class="field"><label for="latest_version">Latest version</label><input type="text" id="latest_version" name="latest_version" required value="<?= e($app['latest_version']) ?>"></div>
    <div class="field"><label for="min_supported_version">Minimum supported version</label><input type="text" id="min_supported_version" name="min_supported_version" required value="<?= e($app['min_supported_version']) ?>"></div>
  </div>
  <div class="field"><label for="download_url">APK download URL</label><input type="url" id="download_url" name="download_url" maxlength="500" placeholder="https://example.com/app.apk" value="<?= e($app['download_url']) ?>"><div class="hint">Used as the default download link. The Update Dialog Manager controls what the API returns.</div></div>
  <div class="field"><label for="description">Update description</label><textarea id="description" name="description" maxlength="2000"><?= e($app['description']) ?></textarea></div>
  <div class="grid-2">
    <div class="field"><label for="icon">Application icon (JPG, PNG, WEBP · max 1 MB)</label>
      <?php if ($isEdit && !empty($app['icon_path'])): ?><div class="app-cell" style="margin-bottom:8px"><img src="<?= e(icon_url($app['icon_path'])) ?>" alt=""><span class="muted small">Current icon. Upload a new file to replace it.</span></div><?php endif; ?>
      <input type="file" id="icon" name="icon" accept="image/jpeg,image/png,image/webp"></div>
    <div class="field"><label>Status</label>
      <div class="switch-row"><div><b>Application active</b><span>Inactive apps are rejected by the API</span></div>
        <label class="switch"><input type="checkbox" name="is_active" value="1" <?= !empty($app['is_active']) ? 'checked' : '' ?>><i></i></label></div></div>
  </div>
  <div class="actions"><button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? 'Save changes' : 'Create application' ?></button><a class="btn" href="applications.php">Cancel</a></div>
</form>
