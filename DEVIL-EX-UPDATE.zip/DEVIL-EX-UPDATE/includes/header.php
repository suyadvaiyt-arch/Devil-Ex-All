<?php
/** Page head + layout opener. Set $layout ('public'|'admin'), $pageTitle, $active before including. */
$layout    = $layout ?? 'public';
$pageTitle = $pageTitle ?? APP_NAME;
$active    = $active ?? '';
$siteName  = get_setting('site_name', APP_NAME);
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> · <?= e($siteName) ?></title>
<link rel="icon" href="assets/images/logo.svg" type="image/svg+xml">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<?php if ($layout !== 'public' || !empty($noindex)): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
</head>
<body class="layout-<?= e($layout) ?>">
<div class="bg-orbs" aria-hidden="true"><span></span><span></span><span></span></div>
<?php if ($layout === 'admin'): ?>
<?php require __DIR__ . '/sidebar.php'; ?>
<div class="nav-backdrop" data-sidebar-toggle></div>
<div class="admin-main">
  <header class="topbar glass">
    <button class="icon-btn menu-btn" type="button" data-sidebar-toggle aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
    <h1 class="topbar-title"><?= e($pageTitle) ?></h1>
    <div class="topbar-user"><i class="fa-solid fa-circle-user"></i> <span><?= e($admin['display_name'] ?? '') ?></span></div>
  </header>
  <main class="content">
  <?php render_flashes(); ?>
<?php elseif ($layout === 'public'): ?>
<header class="pub-nav glass">
  <a class="brand" href="index.php"><img src="assets/images/logo.svg" alt="" width="34" height="34"><span><?= e($siteName) ?></span></a>
  <button class="icon-btn pub-toggle" type="button" data-pubnav-toggle aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
  <nav class="pub-links">
    <a href="index.php#features">Features</a>
    <a href="index.php#how">How it works</a>
    <a href="docs.php">Documentation</a>
    <a href="status.php">Status</a>
    <a class="btn btn-primary btn-sm" href="login.php"><i class="fa-solid fa-lock"></i> Admin</a>
  </nav>
</header>
<?php endif; ?>
