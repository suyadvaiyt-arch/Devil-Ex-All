<?php
/** Closes the layout opened by header.php. */
$layout = $layout ?? 'public';
?>
<?php if ($layout === 'admin'): ?>
  </main>
  <footer class="admin-foot">&copy; <?= date('Y') ?> <?= e(get_setting('site_name', APP_NAME)) ?> · v<?= e(APP_VERSION) ?></footer>
</div>
<?php elseif ($layout === 'public'): ?>
<footer class="pub-foot">
  <div class="wrap">
    <div class="brand"><img src="assets/images/logo.svg" alt="" width="30" height="30"><span><?= e(get_setting('site_name', APP_NAME)) ?></span></div>
    <p><?= e(get_setting('site_tagline', APP_TAGLINE)) ?></p>
    <p class="muted">&copy; <?= date('Y') ?> <?= e(get_setting('site_name', APP_NAME)) ?>. All rights reserved.</p>
  </div>
</footer>
<?php endif; ?>
<script src="assets/js/app.js"></script>
</body>
</html>
