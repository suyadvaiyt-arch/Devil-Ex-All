<?php
/** GET /api/get_app_config.php?app_id=APP_ID  - returns the full stored configuration. */
require_once __DIR__ . '/_common.php';
api_start('get_app_config', ['GET']);

$in = api_input();
[$app, $cfg] = api_find_app($in);

api_ok([
    'app' => [
        'app_id'                => $app['app_id'],
        'name'                  => $app['name'],
        'package_name'          => $app['package_name'],
        'icon_url'              => icon_url($app['icon_path']),
        'current_version'       => $app['current_version'],
        'latest_version'        => $app['latest_version'],
        'min_supported_version' => $app['min_supported_version'],
        'description'           => $app['description'],
    ],
    'config' => [
        'dialog_enabled'             => (int)$cfg['dialog_enabled'] === 1,
        'update_type'                => $cfg['update_type'],
        'latest_version'             => $cfg['latest_version'],
        'latest_version_code'        => (int)$cfg['latest_version_code'],
        'min_supported_version_code' => (int)$cfg['min_supported_version_code'],
        'title'                      => $cfg['title'],
        'message'                    => $cfg['message'],
        'description'                => $cfg['description'],
        'changelog'                  => $cfg['changelog'],
        'download_url'               => $cfg['download_url'],
        'update_button'              => $cfg['update_button_text'],
        'cancel_button'              => $cfg['cancel_button_text'],
        'theme'                      => $cfg['theme'],
        'maintenance_mode'           => (int)$cfg['maintenance_mode'] === 1,
        'maintenance_message'        => $cfg['maintenance_message'],
    ],
]);
