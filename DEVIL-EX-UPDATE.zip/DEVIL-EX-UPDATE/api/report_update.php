<?php
/** POST /api/report_update.php  (app_id, from_version_code, to_version_code) - call after a successful update. */
require_once __DIR__ . '/_common.php';
api_start('report_update', ['POST']);

$in   = api_input();
$from = api_int($in['from_version_code'] ?? null, 'from_version_code');
$to   = api_int($in['to_version_code'] ?? null, 'to_version_code');
$GLOBALS['dx_ctx']['vc'] = $to;
[$app] = api_find_app($in);

if ($to < $from) {
    api_fail(400, 'to_version_code must not be lower than from_version_code.');
}
db()->prepare('INSERT INTO app_events (application_id, event_type, from_version_code, to_version_code, ip_address)
               VALUES (?, \'update\', ?, ?, ?)')
    ->execute([(int)$app['id'], $from, $to, client_ip()]);

api_ok(['message' => 'Update recorded.']);
