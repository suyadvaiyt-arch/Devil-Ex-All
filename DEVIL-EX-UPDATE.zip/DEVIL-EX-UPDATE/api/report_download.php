<?php
/** POST /api/report_download.php  (app_id, version_code) - call when the user taps "Update Now". */
require_once __DIR__ . '/_common.php';
api_start('report_download', ['POST']);

$in = api_input();
$vc = api_int($in['version_code'] ?? null, 'version_code');
$GLOBALS['dx_ctx']['vc'] = $vc;
[$app] = api_find_app($in);

$target = api_int($in['target_version_code'] ?? null, 'target_version_code', false);
db()->prepare('INSERT INTO app_events (application_id, event_type, from_version_code, to_version_code, ip_address)
               VALUES (?, \'download\', ?, ?, ?)')
    ->execute([(int)$app['id'], $vc, $target, client_ip()]);

api_ok(['message' => 'Download recorded.']);
