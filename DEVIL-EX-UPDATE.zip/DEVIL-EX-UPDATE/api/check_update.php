<?php
/** GET /api/check_update.php?app_id=APP_ID&version_code=100 */
require_once __DIR__ . '/_common.php';
api_start('check_update', ['GET']);

$in = api_input();
$vc = api_int($in['version_code'] ?? null, 'version_code');
$GLOBALS['dx_ctx']['vc'] = $vc;
[$app, $cfg] = api_find_app($in);

$latest = (int)$cfg['latest_version_code'];
$min    = (int)$cfg['min_supported_version_code'];

$available = ((int)$cfg['dialog_enabled'] === 1) && $vc < $latest;
$mandatory = $available && ($cfg['update_type'] === 'mandatory' || $vc < $min);

api_ok([
    'update_available'           => $available,
    'mandatory'                  => $mandatory,
    'app_name'                   => $app['name'],
    'latest_version'             => $cfg['latest_version'],
    'latest_version_code'        => $latest,
    'min_supported_version_code' => $min,
    'title'                      => $cfg['title'],
    'message'                    => $cfg['message'],
    'description'                => $cfg['description'],
    'changelog'                  => $cfg['changelog'],
    'download_url'               => $cfg['download_url'],
    'update_button'              => $cfg['update_button_text'],
    'cancel_button'              => $cfg['cancel_button_text'],
    'theme'                      => $cfg['theme'],
    'maintenance_mode'           => (int)$cfg['maintenance_mode'] === 1,
    'maintenance_message'        => $cfg['maintenance_message'],
]);
