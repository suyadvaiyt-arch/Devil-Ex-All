<?php
/** Shared API bootstrap: headers, rate limiting, logging, validation. Not an endpoint. */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$GLOBALS['dx_ctx'] = ['endpoint' => '', 'app_pk' => null, 'vc' => null];

set_exception_handler(static function (Throwable $t): void {
    error_log('DEVIL EX API error: ' . $t->getMessage());
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Internal server error.']);
    exit;
});

function api_start(string $endpoint, array $methods): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: ' . implode(', ', $methods) . ', OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    $GLOBALS['dx_ctx']['endpoint'] = $endpoint;

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
    if (!in_array($method, $methods, true)) {
        header('Allow: ' . implode(', ', $methods));
        api_fail(405, 'Method not allowed.');
    }
    $max = max(1, (int)get_setting('api_rate_limit', '60'));
    $win = max(1, (int)get_setting('api_rate_window_sec', '60'));
    if (!rate_limit_hit('api', client_ip(), $max, $win)) {
        header('Retry-After: ' . $win);
        api_fail(429, 'Too many requests. Please slow down.');
    }
}

function api_log(int $status): void
{
    try {
        if (get_setting('api_logging_enabled', '1') !== '1') {
            return;
        }
        $c = $GLOBALS['dx_ctx'];
        db()->prepare('INSERT INTO api_logs (application_id, endpoint, ip_address, version_code, status_code, user_agent)
                       VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$c['app_pk'], $c['endpoint'], client_ip(), $c['vc'], $status, substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)]);
    } catch (Throwable $t) {
        error_log('DEVIL EX API log failed: ' . $t->getMessage());
    }
}

function api_fail(int $code, string $msg): never
{
    api_log($code);
    json_out(['success' => false, 'error' => $msg], $code);
}

function api_ok(array $data): never
{
    api_log(200);
    json_out(array_merge(['success' => true], $data), 200);
}

/** Merges query string, form fields and a JSON request body. */
function api_input(): array
{
    $in = $_GET;
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $in = array_merge($in, $_POST);
        $raw = file_get_contents('php://input', false, null, 0, 16384);
        if ($raw !== false && $raw !== '' && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
            $j = json_decode($raw, true);
            if (is_array($j)) {
                $in = array_merge($in, $j);
            }
        }
    }
    return $in;
}

function api_int($v, string $name, bool $required = true): ?int
{
    if ($v === null || $v === '') {
        if ($required) {
            api_fail(400, "Missing parameter: $name.");
        }
        return null;
    }
    if (is_int($v)) {
        $n = $v;
    } elseif (is_string($v) && preg_match('/^[0-9]{1,10}$/', $v)) {
        $n = (int)$v;
    } else {
        api_fail(400, "Invalid $name: must be a non-negative integer.");
    }
    if ($n < 0 || $n > 2147483647) {
        api_fail(400, "Invalid $name: out of range.");
    }
    return $n;
}

/** Validates the Application ID and returns [application row, config array]. */
function api_find_app(array $in): array
{
    $appId = $in['app_id'] ?? '';
    if (!is_string($appId) || $appId === '') {
        api_fail(400, 'Missing parameter: app_id.');
    }
    if (!valid_app_id($appId)) {
        api_fail(400, 'Invalid app_id format.');
    }
    $st = db()->prepare('SELECT * FROM applications WHERE app_id = ?');
    $st->execute([$appId]);
    $app = $st->fetch();
    if (!$app) {
        api_fail(404, 'Application not found.');
    }
    $GLOBALS['dx_ctx']['app_pk'] = (int)$app['id'];
    if ((int)$app['is_active'] !== 1) {
        api_fail(403, 'This application is currently disabled.');
    }
    return [$app, get_config((int)$app['id'], $app)];
}
